#!/bin/bash
# Install script for CYA-kenya app dependencies
npm install